var searchData=
[
  ['login_0',['Login',['../class_vacation_manager_1_1_controllers_1_1_home_controller.html#af440ab9fbb870ce3d2a435da16097495',1,'VacationManager.Controllers.HomeController.Login()'],['../class_vacation_manager_1_1_controllers_1_1_home_controller.html#a17c2eb01c65334c721b57781d7935b04',1,'VacationManager.Controllers.HomeController.Login(UserCreateVM model)']]],
  ['logout_1',['Logout',['../class_vacation_manager_1_1_controllers_1_1_home_controller.html#aa2b80ce4a6a6ce203b625f932547faa1',1,'VacationManager::Controllers::HomeController']]]
];
