var searchData=
[
  ['errorviewmodel_0',['ErrorViewModel',['../class_vacation_manager_1_1_models_1_1_error_view_model.html',1,'VacationManager::Models']]]
];
