var searchData=
[
  ['startup_0',['Startup',['../class_vacation_manager_1_1_startup.html#a39adfcb7f950928c174ce3183e57453c',1,'VacationManager::Startup']]]
];
