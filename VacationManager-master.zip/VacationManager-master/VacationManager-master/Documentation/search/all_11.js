var searchData=
[
  ['requestid_0',['RequestId',['../class_vacation_manager_1_1_models_1_1_error_view_model.html#a0a0f827537a5c943d92dfa03dd9c6a6f',1,'VacationManager::Models::ErrorViewModel']]],
  ['requestinguser_1',['RequestingUser',['../class_vacation_manager_1_1_models_1_1_time_off.html#a0066f22cc3709991208e957d8b9f14ce',1,'VacationManager::Models::TimeOff']]],
  ['role_2',['Role',['../class_vacation_manager_1_1_models_1_1_user.html#ac46cc872b306f3fe7490be5a17280adc',1,'VacationManager::Models::User']]],
  ['rolescontroller_3',['RolesController',['../class_vacation_manager_1_1_controllers_1_1_roles_controller.html#af5c7cc48938d22322e1a1a9cce47e9d7',1,'VacationManager.Controllers.RolesController.RolesController()'],['../class_vacation_manager_1_1_controllers_1_1_roles_controller.html',1,'VacationManager.Controllers.RolesController']]],
  ['rolescontroller_2ecs_4',['RolesController.cs',['../_roles_controller_8cs.html',1,'']]]
];
