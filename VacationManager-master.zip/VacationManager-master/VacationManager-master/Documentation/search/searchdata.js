var indexSectionsWithContent =
{
  0: ".2_abcdefhijlmnoprstuvw",
  1: "cdehiprstuv",
  2: "av",
  3: ".2_cdehilprstuv",
  4: "bcdeilmoprstuv",
  5: "acdfhjlmnprstuw",
  6: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "properties",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Properties",
  6: "Pages"
};

