var searchData=
[
  ['name_0',['Name',['../class_vacation_manager_1_1_models_1_1_project.html#a05842bd82ac19479d57dbf1645b7b628',1,'VacationManager.Models.Project.Name()'],['../class_vacation_manager_1_1_models_1_1_team.html#a643994b213d7c5715bdee2b7ee04b316',1,'VacationManager.Models.Team.Name()']]]
];
