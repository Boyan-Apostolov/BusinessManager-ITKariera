var searchData=
[
  ['vacationmanagerdbcontext_0',['VacationManagerDbContext',['../class_vacation_manager_1_1_repositories_1_1_vacation_manager_db_context.html#a9495ac725bcd508b2b079c3da64a016e',1,'VacationManager::Repositories::VacationManagerDbContext']]]
];
