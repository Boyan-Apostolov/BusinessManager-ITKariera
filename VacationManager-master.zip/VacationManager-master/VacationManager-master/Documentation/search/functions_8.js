var searchData=
[
  ['projectscontroller_0',['ProjectsController',['../class_vacation_manager_1_1_controllers_1_1_projects_controller.html#abe32cf239d27faf05be35864978a5c7f',1,'VacationManager::Controllers::ProjectsController']]]
];
