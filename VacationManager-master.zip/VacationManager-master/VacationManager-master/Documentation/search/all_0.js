var searchData=
[
  ['_2enetcoreapp_2cversion_3dv5_2e0_2eassemblyattributes_2ecs_0',['.NETCoreApp,Version=v5.0.AssemblyAttributes.cs',['../_8_n_e_t_core_app_00_version_0av5_80_8_assembly_attributes_8cs.html',1,'']]]
];
