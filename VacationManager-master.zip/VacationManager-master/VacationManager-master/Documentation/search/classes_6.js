var searchData=
[
  ['rolescontroller_0',['RolesController',['../class_vacation_manager_1_1_controllers_1_1_roles_controller.html',1,'VacationManager::Controllers']]]
];
