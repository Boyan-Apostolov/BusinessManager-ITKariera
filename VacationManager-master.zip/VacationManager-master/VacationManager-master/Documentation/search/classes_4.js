var searchData=
[
  ['initial_0',['Initial',['../class_vacation_manager_1_1_migrations_1_1_initial.html',1,'VacationManager::Migrations']]]
];
