var searchData=
[
  ['workingprojects_0',['WorkingProjects',['../class_vacation_manager_1_1_models_1_1_team.html#ae1967503649fc953fd14358d7ec9090a',1,'VacationManager::Models::Team']]]
];
