var searchData=
[
  ['approved_0',['Approved',['../class_vacation_manager_1_1_models_1_1_time_off.html#abca1b9bfd6be116bc3dcaec6f9d698e9',1,'VacationManager::Models::TimeOff']]]
];
