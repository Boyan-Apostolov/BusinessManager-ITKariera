var searchData=
[
  ['rolescontroller_0',['RolesController',['../class_vacation_manager_1_1_controllers_1_1_roles_controller.html#af5c7cc48938d22322e1a1a9cce47e9d7',1,'VacationManager::Controllers::RolesController']]]
];
