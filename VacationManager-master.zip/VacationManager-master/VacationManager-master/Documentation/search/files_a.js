var searchData=
[
  ['rolescontroller_2ecs_0',['RolesController.cs',['../_roles_controller_8cs.html',1,'']]]
];
