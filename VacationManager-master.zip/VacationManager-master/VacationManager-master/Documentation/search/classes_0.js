var searchData=
[
  ['customdaterange_0',['CustomDateRange',['../class_vacation_manager_1_1_models_1_1_custom_date_range.html',1,'VacationManager::Models']]]
];
