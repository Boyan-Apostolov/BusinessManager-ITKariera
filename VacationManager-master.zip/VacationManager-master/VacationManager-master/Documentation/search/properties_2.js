var searchData=
[
  ['description_0',['Description',['../class_vacation_manager_1_1_models_1_1_project.html#a6ad730ca27cd90a49f8c70cc9b2591b7',1,'VacationManager::Models::Project']]],
  ['developers_1',['Developers',['../class_vacation_manager_1_1_models_1_1_team.html#a26150bbccf46b87aa81d207fdbe1851d',1,'VacationManager::Models::Team']]]
];
