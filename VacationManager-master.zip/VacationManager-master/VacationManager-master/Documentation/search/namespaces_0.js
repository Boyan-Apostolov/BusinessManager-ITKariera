var searchData=
[
  ['aspnetcore_0',['AspNetCore',['../namespace_asp_net_core.html',1,'']]]
];
