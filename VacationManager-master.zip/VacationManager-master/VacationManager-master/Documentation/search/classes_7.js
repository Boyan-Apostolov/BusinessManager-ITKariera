var searchData=
[
  ['startup_0',['Startup',['../class_vacation_manager_1_1_startup.html',1,'VacationManager']]]
];
